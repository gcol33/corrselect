library(testthat)
library(corrselect)

test_check("corrselect")

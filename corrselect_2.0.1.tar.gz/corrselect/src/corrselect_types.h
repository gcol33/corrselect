#ifndef CORRSELECT_TYPES_H
#define CORRSELECT_TYPES_H

#include <vector>

typedef std::vector<int> Combo;
typedef std::vector<Combo> ComboList;

#endif
